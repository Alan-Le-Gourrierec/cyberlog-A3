(***** Exercice 1.1 (préliminaires) *****)

(* Question 1 *)
(*
type hanoi = 
;;
*)

(* Question 2 *)
(*
let tour1 = ;; 
let tour2 = ;; 
let tour3 = ;;
let tour3bis = ;;
let jeu1 = ;;
let jeu2 = ;;
let jeu3 = ;;
*)

(* Question 3 *)
(*
let rec check t1 = 
;;
*)

(* Question 4 *)
(*
let make p1 p2 p3 =
;;
*)


(***** Exercice 1.2 (affichage) *****)

(* Question 1 *)
let hd_tl_opt lst = 
   match lst with 
   | []		-> (None, []) 
   | x::l	-> (Some x, l)
;;

(*    
let rec combine_aux lst1 lst2 lst3 res =
;;

let combine lst1 lst2 lst3 =
;;
*)

(* Question 2 *)
let print_option = function
  | None   -> Printf.printf "   "
  | Some i -> Printf.printf "%3i" i
;;

(*
let rec print_list lst =
;;
*)
    
(* Question 3 *)
(*
let print_hanoi hanoi =
;;
*)

(* Question 4 *)
(*
let rec print_hanoi_list hl =
;;
*)
  


(***** Exercice 1.3 (résolution) *****)
(* Question 1 *)
let move ls1 ls2 =
  match ls1 with
  | []       -> ls1, ls2
  | x :: ls1 -> ls1, x :: ls2

(* Attention : la fonction "play" est de type "hanoi -> int -> int -> hanoi". *)
(*
let play {t1; t2; t3} src dst =
;;
*)


(* Question 2 *)
(*
let rec compute_aux n src dst aux res =
  if n = 0 
  then ... 
  else
      (* à la fin on déplace n-1 disques de aux vers dst *) 
      ...
      (* juste avant ça on déplace 1 disque de src vers dst *) 
      ...
      (* avant ça on déplace n-1 disques de src vers aux *) 
      ...
;;
*)
(*
let compute n src aux dst = 
;;
*)


(* Question 3 *)
(*
let rec apply_acc hanoi moves acc =
;;
*)
(*
let apply hanoi moves = 
;;      
*)
		
(* Question 4 *)		
(*
let hanoi_towers n =
;;
*)