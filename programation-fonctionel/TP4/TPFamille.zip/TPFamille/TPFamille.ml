(* Question 1 : Création des données *)




(* Question 2 : Prédicat "a_un_pere" *)

(*
let rec a_un_pere personne population =
;;  
*)

(* Question 3 : Fonction "pere" *)

(*
let rec pere personne population =
;;
*)

(* Question 4 : Fonction "lignage" *)

(*
let lignage personne population = 
;;
*)

(* Question 5 : Fonction "dernier" *)

(*
let dernier l =
;;
*)

(* Question 6 : Prédicat "frere" *)

(*
let frere p1 p2 population = 
;;
*)

(* Question 7 : Fonction "liste_lignages" *)

(*
let liste_lignages population = 
;;
*)


(* Question 8 : Fonction "liste_ancetres" *)

(*
let liste_ancetres liste_lignage = 
;;
*)


(* Question 9 : Fonction "sans_double" *)

(*
let rec sans_double l =
;;
*)

(* Question 10 : Retour vers les questions *)

(* Déterminer si deux personnes p1 et p2 sont « frères de lignage » dans la population pop1. A noter que p1, p2 et pop1 ont été définies dans la question 1. *)


(* Combien de lignages avons-nous pour les populations pop1 et pop2. A noter que pop1 et pop2 ont été définies dans la question 1. *)

