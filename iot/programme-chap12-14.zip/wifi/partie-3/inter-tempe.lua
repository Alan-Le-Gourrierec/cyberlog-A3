<h1> LE CHAUFFAGE EST ALLUMEE !!!! </h1>

<?lua
    print("Temperature : "..s:read("temperature").." Humitite : "..s:read("humidity"))
?>
