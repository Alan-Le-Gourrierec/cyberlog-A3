<?lua
    ledon()
    tmr.delayms(200)
    ledoff()
?>
