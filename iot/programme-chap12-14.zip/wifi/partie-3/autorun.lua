w = net.wf.scan(true) --fait un scan des réseaux environnants

dofile("console.lua")
dofile("wifi.lua")

--cette fonction permet de lancer le reseau et le serveur web
StartAlan()