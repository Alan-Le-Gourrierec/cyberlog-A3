<h1> Hola cabrone </h1>

<?lua
        ledon()
        tmr.delayms(200)
        ledoff()
        console("marche de grace") -- ca prends pas les accents ...
?>

<h1> CA VA TU MARCHE ENFIN !!!!!! </h1>