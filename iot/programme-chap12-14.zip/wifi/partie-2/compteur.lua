<h1> Hola cabrone </h1>

<?lua
        nb = nb + 1 --nb est une variable globale 
        print("nous avons rafraichi "..nb.." fois cette page")
?>


