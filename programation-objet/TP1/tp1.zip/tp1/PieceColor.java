/**
 * Enumeration of chess pieces colors
 *
 * @author Pascale Launay
 */

public enum PieceColor
{
    white, black
}
