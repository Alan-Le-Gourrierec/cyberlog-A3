/**
 * A chess piece. Represented by a location in the chessboard (x,y),
 * a name and a color.
 *
 * @author Pascale Launay
 */
public class Piece
{
    /**
     * The piece name: PAWN, ROOK, KNIGHT, BISHOP, QUEEN, KING.
     */
    private final PieceName name;

    /**
     * The piece color: black, white.
     */
    private final PieceColor color;

    /**
     * Constructs a piece with given name and color.
     *
     * @param name  the piece name: PAWN, ROOK, KNIGHT, BISHOP, QUEEN, KING.
     * @param color the piece color: black, white.
     */
    public Piece(PieceName name, PieceColor color)
    {
        this.name = name;
        this.color = color;
    }

    /**
     * Moves the piece. After the movement, the new location of the piece should be
     * (x+dx,y+dy)
     *
     * @param dx the horizontal movement.
     * @param dy the vertical movement.
     */
    public void move(int dx, int dy)
    {
        // TODO
    }

    /**
     * Gives a string representation of the piece in the form "name color".
     *
     * @return a string representation of the piece.
     */
    @Override
    public String toString()
    {
        return this.name + " " + this.color;
    }
}
