package backend;

import frontend.Game;

import java.awt.Color;
import java.util.ArrayList;

import javax.swing.JOptionPane;
import javax.swing.JTextArea;
import javax.swing.border.EmptyBorder;

/**
 * Un objet Grille représentant la carte navale contenant :
 * un tableau des cases de la grille
 * la liste des bateaux sur la grille
 * la liste des bateaux coulés sur la grille
 * la taille de la carte
 * le nombre de cases en abscisses
 * le nombre de cases en ordonnées
 * un tableau d'affichage pour l'utilisateur
 * @author Alan Le Gourrierec, Joseph De L'Estourbeillon, Ewan Pallavicini
 */

public class Grille {
    // Attributs //
    private Case [][] cases;
    private ArrayList<Bateau> listeBateau;
    private ArrayList<Bateau> listeBateauCoule;

	// Parametre d'affichage de la carte
	public final int tailleCase = 25;
    final private int taille_x = 10;
    final private int taille_y = 10;

    private JTextArea[][] tableauJTextArea =  new JTextArea[taille_x][taille_y];

    // Constructeur //
    /**
     * Constructeur de la grille
     */
    public Grille(){
        listeBateau = new ArrayList<Bateau>();
        listeBateauCoule = new ArrayList<Bateau>();

        cases = new Case[this.taille_x][this.taille_y];
        casesInit();

        for (int i = 0; i < taille_x; i++) {
			for (int j = 0; j < taille_y; j++) {
				tableauJTextArea[i][j] = new JTextArea(); // taille de la grille
			}
		}
    }


    // Methodes //
    /**
     * Initialise toutes les cases du tableau en créant un nouvel objet case
     * appelé par le constructeur
     */
    private void casesInit(){
        for (int i = 0 ; i < taille_x ; i++){
            for (int j = 0 ; j < taille_y ; j++){
                this.cases[i][j] = new Case(i,j);
            }
        }
    }

    /**
     * Permet d'effectuer une attaque sur une case de cette grille
     * @param x position x de la case attaquée
     * @param y position y de la case attaquée
     * @return le résultat du tir qui est un élément de l'énumération TypeTir
     */
    public TypeTir attaque(int x,int y){
        if (cases[x][y].getTouche()){
            return null;
        }
        else if (cases[x][y].getIdVaisseau()!=0){
            tableauJTextArea[x][y].setBackground(Color.ORANGE);
            cases[x][y].setTorpiller();
            
            if (verifBateauCoule(cases[x][y])){
                for (Bateau elem : listeBateau){
                    if (this.getCaseBateau(elem).contains(this.cases[x][y]) && this.cases[x][y].getIdVaisseau()==elem.getType().getTaille()){
                        JOptionPane.showMessageDialog(Game.contentPanel,"Bateau coulé : "+elem.getType().name());
                        listeBateauCoule.add(elem);
                    }
                }
                return TypeTir.coule;
            }
            return TypeTir.touche;
        }
        
        cases[x][y].setTorpiller();
        tableauJTextArea[x][y].setBackground(Color.BLUE);
        return TypeTir.rate;
    }

    /**
     * Vérifie si le bateau est coulé
     * @param caseVise case du bateau que l'on veut tester
     * @return true si le bateau est coulé, false si une case du bateau n'est pas touché 
     */
    private boolean verifBateauCoule(Case caseVise){
        assert caseVise.getIdVaisseau()!=0;

        this.afficherTableauStr();

        Bateau bateauVise = null;
        
        // On recherche quel bateau a ete visé
        for (Bateau bateau : this.listeBateau) {
            if (this.getCaseBateau(bateau).contains(caseVise)){
            // if (bateau.getType().getTaille()==caseVise.getIdVaisseau()){
                System.out.print(bateau.getType().name());
                System.out.println(bateau.getType().getTaille());
                bateauVise = bateau;
                break;
            }
        }

        assert bateauVise!=null;
        
        // Si au moins une case du bateau n'est pas touché alors le bateau n'est pas coulé
        for (Case elem: getCaseBateau(bateauVise)){
            if (!elem.getTouche()){
                return false;
            }
        }
        return true;
    }

    /**
     * Ajoute un bateau à la grille
     * @param vaisseau vaisseau que l'on ajoute à la grille
     */
    public void ajoutVaisseau(Bateau vaisseau){
        int x = vaisseau.getCoordonneeesDebutPosx();
        int y = vaisseau.getCoordonneeesDebutPosy();
        boolean orientation = vaisseau.getOrientation();
        boolean axe = vaisseau.getAxe();
        int taille = vaisseau.getType().getTaille();
        
        listeBateau.add(vaisseau);

        for(int i=0;i<taille;i++){
            this.cases[x][y].vaisseau(taille);
            System.out.println("Case bateau "+x+" "+y+" "+this.cases[x][y].getIdVaisseau());
            if(axe & orientation){
                x++;
            }
            if(axe & !orientation){
                x--;
            }
            if(!axe & !orientation){
                y++;
            }
            if(!axe & orientation){
                y--;
            }
        }

        System.out.println(" |-> "+vaisseau.getType()+" ajouté à la grille");
    }

    /**
     * Vérifie si le placement du bateau est correct
     * @param vaisseau bateau que l'on veut placer
     * @return true si le placement est correct, false si le placement est incorrect
     */
    public boolean isValidPlace(Bateau vaisseau){
        if (!isSurPlateau(vaisseau)){
            return false;
        }
        if (!isPlaceVide(vaisseau)){
            System.out.println("[x] Données invalides : le vaisseau deborde sur un autre vaisseau");
            JOptionPane.showMessageDialog(Game.contentPanel, "Le vaisseau dépasse sur un autre vaisseau !", "Erreur", JOptionPane.WARNING_MESSAGE);
            return false;
        }
        return true;
    }

    /**
     * Vérifie si le vaisseau est sur le plateau
     * @param vaisseau bateau pour lequel on veut vérifier qu'il est sur le bateaux
     * @return true si le bateau est entièrement sur le plateau, false sinon
     * appelé par isValidPlace()
     */
    private boolean isSurPlateau(Bateau vaisseau){
        int x = vaisseau.getCoordonneeesDebutPosx();
        int y = vaisseau.getCoordonneeesDebutPosy();
        int taille = vaisseau.getType().getTaille();
        boolean axe = vaisseau.getAxe();
        boolean orientation = vaisseau.getOrientation();
        String info = "";
        
        // 
        if (x<0 | x>=10) info += "(x invalide)";
        if (y<0 | y>=10) info += "(y invalide)";
        
        if(axe & orientation){
            if (x+taille-1>=10) info += "(diminuer x)";
        }
        if(axe & !orientation){
            if (x-taille+1<0) info += "(augmenter x)";
        }
        if(!axe & orientation){
            if (y-taille+1<0) info += "(augmenter y)";
        }
        if(!axe & !orientation){
            if (y+taille-1>=10) info += "(diminuer y)";
        }
        
        if (info != ""){
            System.out.println("Le vaisseau dépassse du plateau : "+info);
            JOptionPane.showMessageDialog(Game.contentPanel, "Le vaisseau dépasse du plateau ! \n"+info, "Erreur", JOptionPane.WARNING_MESSAGE);
            return false;
        }
        return true;
    }

    /**
     * Vérifie si la place à laquelle on veut placer un bateau bateau n'est pas déjà prise
     * @param vaisseau le bateau que l'on veut placer
     * @return true si la place est vide, false si elle est occupe
     * appelé par isValidPlace()
     */

    private boolean isPlaceVide(Bateau vaisseau){
        for (Case elem : getCaseBateau(vaisseau)){
            if (elem.getIdVaisseau()!=0){
                return false;
            }
        }
        return true;
    }

    /**
     * Renvoie la liste des cases d'un bateau à une méthode de la classe
     * @param bateau bateau pour lequel on veut récupérer les cases
     * @return la liste des cases du bateau
     */
    private ArrayList<Case> getCaseBateau(Bateau bateau){
        ArrayList<Case> caseBateau = new ArrayList<>();

        int x = bateau.getCoordonneeesDebutPosx();
        int y = bateau.getCoordonneeesDebutPosy();
        boolean axe = bateau.getAxe();
        boolean orientation = bateau.getOrientation();

        for (int i=0;i<bateau.getType().getTaille();i++){
            caseBateau.add(cases[x][y]);
            if(axe & orientation){
                x++;
            }
            if(axe & !orientation){
                x--;
            }
            if(!axe & !orientation){
                y++;
            }
            if(!axe & orientation){
                y--;
            }
        }
        return caseBateau;
    }

    // getter
    /**
     * retourne la case que l'on souhaite obtenir
     * @param i position x de la case souhaitée
     * @param j position y de la case souhaitée
     * @return la case (i,j)
     */
    public Case getCase(int i,int j){
        return this.cases[i][j];
    }
    /**
     * @return la taille de la grille en largeur
     */
    public int getTailleX(){
        return this.taille_x;
    }
    /**
     * @return la taille de la grille en hauteur
     */
    public int getTailleY(){
        return this.taille_y;
    }
    /**
     * @return la grille
     */
    public JTextArea[][] getPlateau(){
        return this.tableauJTextArea;
    }
    /**
     * @return si tous les bateaux de la grille sont coulés
     */
    public boolean bateauTousCoule(){
        return listeBateauCoule.size()==listeBateau.size();
    }
    /**
     * @return le nombre de bateaux coulés
     */
    public int getNbrBateauCoule(){
        return listeBateauCoule.size();
    }
    

    // Méthode d'affiche
    /**
     * Affiche au joueur le plateau
     * @param pos_x position du plateau selon l'axe x
     * @param pos_y position du plateau selon l'axe y
     * @param adversaire true si la grille appartient à l'adversaire, false sinon
     */
    public void affichagePlateau(int pos_x, int pos_y, Boolean adversaire) {
        JTextArea[][] tableauJTextArea = this.getPlateau();
        int y = pos_y;

        if (adversaire) pos_x += 440;

		for (int i=0; i<taille_x; i++){
			for (int j=0; j<taille_y; j++){
                // Coloriage des cases
                if (this.getCase(i,j).getTouche()){
                    if (this.getCase(i,j).getIdVaisseau()!=0){
                        tableauJTextArea[i][j].setBackground(Color.ORANGE);
                        for (Bateau elem: listeBateauCoule){
                            if (this.getCaseBateau(elem).contains(this.cases[i][j]) && this.cases[i][j].getIdVaisseau()==elem.getType().getTaille()){
                                tableauJTextArea[i][j].setBackground(Color.RED);
                            }
                        }
                    }
                    else {
                        tableauJTextArea[i][j].setBackground(Color.BLUE);
                    }
                }
                else {
                    tableauJTextArea[i][j].setBackground(new Color(200,200,255));
                    if (!adversaire && this.getCase(i,j).getIdVaisseau()!=0){
                        tableauJTextArea[i][j].setForeground(Color.WHITE);
                        tableauJTextArea[i][j].setBackground(Color.BLACK);
                    }
                }

                // Affichage de l'id des vaisseau
                tableauJTextArea[i][j].setText("");
                if (this.getCase(i,j).getIdVaisseau()!=0){
                    if (!adversaire){
                        tableauJTextArea[i][j].setText(" "+this.getCase(i,j).getIdVaisseau()+"");
                    }
                    else{
                        // Si c'est le plateau de l'adversaire on affiche l'id seulement si le bateau est coulé
                        for (Bateau elem: listeBateauCoule){
                            if (this.getCaseBateau(elem).contains(this.cases[i][j]) && this.cases[i][j].getIdVaisseau()==elem.getType().getTaille()){
                                tableauJTextArea[i][j].setText(" "+this.getCase(i,j).getIdVaisseau()+"");
                            }
                        }
                    }
                }

				tableauJTextArea[i][j].setBounds(pos_x,pos_y, tailleCase, tailleCase);
                tableauJTextArea[i][j].setBorder(new EmptyBorder(5, 5, 5, 5));
				tableauJTextArea[i][j].setEditable(false);

                Game.contentPanel.add(tableauJTextArea[j][i]);
				pos_y+=tailleCase+1;
			}
			pos_x+= tailleCase+1;
			pos_y = y;
			
		}
        setVisiblePlateau(true);
	}

    /**
     * affiche ou cache le tableau
     * @param etat état dans lequel on veut trouver le tableau
     * @post le tableau doit être affiché dans l'état d'entré, visible si true, caché si false
     */
    public void setVisiblePlateau(boolean etat){
		int lignes = tableauJTextArea.length;
		int colonnes = tableauJTextArea[0].length;

		for (int i = 0; i < lignes; i++) {
			for (int j = 0; j < colonnes; j++) {
				tableauJTextArea[i][j].setVisible(etat);
			}
		}
	}

    /**
     * affiche le tableau sur le terminal
     */
    public void afficherTableauStr(){
        for (int i = 0 ; i < 10 ; i++){
            for (int j = 0 ; j < 10 ; j++){
                System.out.print(this.cases[i][j].getIdVaisseau()+" ");
            }
            System.out.println();
        }
    }

}
