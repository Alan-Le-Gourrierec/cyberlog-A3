package backend;

/**
 * Enumération du type de bateau avec une taille constante pour chaque bateau différent
 * @author Alan Le Gourrierec, Joseph De L'Estourbeillon, Ewan Pallavicini
 */

public enum TypeVaisseau {
  porteAvion(5), croiseur(4), contreTorpilleur(3), torpilleur(2);

  private final int taille;

  /**
   * Constructeur du vaisseau
   * @param taille taille du bateau constante
   */
  private TypeVaisseau(int taille) {
    this.taille = taille;
  }

  /**
   * getter de la taille du bateau
   * @return la taille du bateau
   */
  public int getTaille() {
    return this.taille;
  }
}