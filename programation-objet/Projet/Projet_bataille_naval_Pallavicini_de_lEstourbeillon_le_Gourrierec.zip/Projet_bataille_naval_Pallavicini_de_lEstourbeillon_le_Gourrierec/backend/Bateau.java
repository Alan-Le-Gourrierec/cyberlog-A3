package backend;

/**
 * Un objet Bateau contenant :
 * l'état du bateau si il est coulé
 * la position x de l'avant du bateau
 * la position y de l'avant du bateau
 * l'axe selon horizontal ou vertical
 * le sens par rapport a l'avant du bateau et l'axe
 * le type du bateau
 * @author Alan Le Gourrierec, Joseph De L'Estourbeillon, Ewan Pallavicini
 */

public class Bateau {

    // attributs 
    private boolean coule;
    private int coordonneesDebutPosx;
    private int coordonneesDebutPosy;
    private boolean axe; //se place sur l'axe des absisces si true ou false pour l'axe des ordonnées 
    private boolean sensOrientation;  
    private TypeVaisseau bateau;
    
    // constructeur
    /**
     * 
     * @param startPosx coordonnées x sur laquelle est la 1er case du bateau  
     * @param startPosy coordonnées y sur laquelle est la 1er case du bateau
     * @param sensOrientation représente ma dorection dans lequel est le bateau (true = vers le haut ou vers la droite/ 
     * false = vers le bas ou vers la gauche)
     * @param axe représente l'axe sur lequelle le bateau est (true = abscisse / false = ordonnée)
     * @param boat bateau représente le type de bateau, ceci permet de définir la taille du bateau par la suite 
     * 
     * @pre les coordonnées x et y sont comprisent entre 0 et 9 en ajoutant la taille du beateau. La variable boat est initialisé
     * avec une des valeurs dans le type énumération TypeVaisseau, l'axe à été initialisé avec true ou false tout comme sensOrientation
     * @post toites les cases du bateau sont dans la grille et orienté en fontion de sensOrientation et axe,
     * axe, sensOrientation, coordonneesDebutPosx et coordoneesDebutPosy et bateau ont été initialisé.
     */
    public Bateau(int startPosx, int startPosy,boolean sensOrientation, boolean axe, TypeVaisseau boat){
        assert startPosx>=0 & startPosx<10;
        assert startPosy>=0 & startPosy<10;
        assert boat != null;
        
        this.bateau = boat;
        this.coordonneesDebutPosx = startPosx;
        this.coordonneesDebutPosy = startPosy;
        this.axe = axe;
        this.sensOrientation = sensOrientation;
        this.coule = false;

        assert bateau != null;
        assert coordonneesDebutPosx >=0 && coordonneesDebutPosx < 10;
        assert coordonneesDebutPosy >=0 && coordonneesDebutPosy < 10;
        assert this.axe == axe;
        assert this.sensOrientation == sensOrientation;
    }


    // Methode
    /**
     * @post la valeur de coule est passé à true
     */
    public boolean coule(){
        return this.coule = true;
    }


    // Getters
    /**
     * @post la valeur de bateau n'est pas modifié 
     * @return retourne la catégorie du bateau
     */
    public TypeVaisseau getType() {
        assert this.bateau != null;
        return this.bateau;
    }
    /**
     * @post la valeur de coordonneesDebutPosx n'est pas modifié
     * @return retourne la valeur de coordonneesDebutPosx
     */
    public int getCoordonneeesDebutPosx() {
        return this.coordonneesDebutPosx;
    }
    /**
     * @post la valeur de coordoneesDebutPosy n'est pas modifié
     * @return retourne la valeur de coordoneesDebutPosy
     */
    public int getCoordonneeesDebutPosy() {
        return this.coordonneesDebutPosy;
    }

    public boolean getAxe(){
        return this.axe;
    }

    public boolean getOrientation(){
        return this.sensOrientation;
    }
}
