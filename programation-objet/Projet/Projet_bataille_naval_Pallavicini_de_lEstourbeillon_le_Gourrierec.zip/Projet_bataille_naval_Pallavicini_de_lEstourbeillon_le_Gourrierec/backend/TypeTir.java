package backend;

/**
 * Enumération du type de tir effectué
 * @author Alan Le Gourrierec, Joseph De L'Estourbeillon, Ewan Pallavicini
 */

public enum TypeTir {
  rate, touche, coule
}