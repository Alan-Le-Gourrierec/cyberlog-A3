package backend;

import frontend.Game;

import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.JFrame;
import javax.swing.JTextArea;

/**
 * Un objet Joueur contenant :
 * l'identifiant du joueur
 * le nom du joueur
 * l'âge du joueur
 * la grille associée au joueur
 * le joueur adversaire
 * le nombre de tours depuis le lancement de la partie
 * si le joueur a gagné la partie
 * @author Alan Le Gourrierec, Joseph De L'Estourbeillon, Ewan Pallavicini
 */

public class Joueur extends JFrame{
    // Attributs //
    private int ID;
    private String nom;
    private String prenom;
    private int age;
    private Grille grille;
    private Joueur adversaire;
    private int nbrTour;
    private boolean gagner;

    // Constructeur //
    /**
     * Constructeur du joueur
     * @param ID numero du joueur
     * @param nom information sur le nom du joueur 
     * @param prenom information sur le prénom du joueur
     * @param age age du joueur
     */
    public Joueur(int ID, String nom, String prenom, int age){
        this.ID = ID;
        this.nom = nom;
        this.prenom = prenom;
        this.age = age;
        this.grille = new Grille();
        this.nbrTour = 0;
        this.gagner = false;
    }


    public void torpiller(){
        for (int i = 0; i < grille.getTailleX(); i++) {
            for (int j = 0; j < grille.getTailleY(); j++) {
                ajoutListenerCase(i, j);
            }
        }
	}
    private void ajoutListenerCase(int i, int j){
        this.adversaire.grille.getPlateau()[i][j].addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent e) {
                JTextArea clickedTextArea = (JTextArea) e.getSource();
                
                // Vérifie si c'est bien le plateau de l'adversaire
                if (clickedTextArea.getX()>500){
                    System.out.println("  -> Case torpillée : (" + i + ", " + j + ")");
                    TypeTir tir = null;
                    tir = adversaire.grille.attaque(i, j);
                    System.out.println(tir);
                    Game.contentPanel.repaint();
                }
            }
        });
    }


    // Setters
    /**
     * @param joueur
     * Ajoute un adversaire au joueur actuel
     */
    public void setAdversaire(Joueur joueur){
        this.adversaire = joueur;
    }
    /**
     * Ajoute un tour au compteur de tour du joueur
     */
    public void addUnTour(){
        this.nbrTour++;
    }

    // Getters
    /**
     * @post la valeur de ID n'est pas modifié
     * @return la valeur de ID
     */
    public int getID() {
        return this.ID;
    }
    /**
     * @return la valeur stocké dans nom
     */
    public String getNom() {
        return this.nom;
    }
    /**
     * @return la valeur stocké dans prénom
     */
    public String getPrenom() {
        return this.prenom;
    }
   /**
     * @return la valeur stocké dans age
     */
    public int getAge() {
        return this.age;
    }
    /**
     * @return la grille relative au joueur
     */
    public Grille getGrille(){
        return this.grille;
    }
    /**
     * @return l'adversaire du joueur
     */
    public Joueur getAdversaire(){
        return this.adversaire;
    }
    /**
     * @return le nombre de tour actuel du joueur
     */
    public int getNbrTour(){
        return this.nbrTour;
    }

    public boolean aGagner(){
        this.gagner = this.grille.bateauTousCoule();
        return this.gagner;
    }
}
