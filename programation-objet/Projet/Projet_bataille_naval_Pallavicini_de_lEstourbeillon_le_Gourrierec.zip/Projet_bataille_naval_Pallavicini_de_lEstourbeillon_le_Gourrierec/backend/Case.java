package backend;

/**
 * Un objet Case contenant :
 * la position x de la case
 * la position y de la case
 * si la case a été torpillée
 * l'identifiant du bateau dans la case
 * @author Alan Le Gourrierec, Joseph De L'Estourbeillon, Ewan Pallavicini
 */

public class Case {

    // attributs //
    private int posx; //position x de l'entité
    private int posy; //position y de l'entité
    private boolean torpille = false; //la case a ete torpillee ou non
    private int idVaisseau = 0; //il n'y a pas de bateau dans les cases initialement


    // constructeur //
    /**
     * @pre nous devons entrer une valeur pour x et y comprise entre 0 et 9.    
     * @param x valeur entree representant la position de la case selon l'axe des abscisses
     * @param y valeur entree representant la position de la case selon l'axe des ordonnees
     */
    public Case(int x, int y){
        assert x<0 & x>9;
        assert y<0 & y>9;

        this.posx = x;
        this.posy = y;
    }

    // setter
    /**
     * Défini la classe comme torpillée
     * @pre la case n'est pas torpillée
     */
    public void setTorpiller(){
        this.torpille = true;
    }
    /**
     * défini l'id du vaisseau
     * @param id id à attribuer
     */
    public void vaisseau(int id){
        this.idVaisseau = id;
    }

    // getter
    /**
    * @post la valeur de posx n'est pas modifié
    * @return posx 
    */
    public int getPosx() {
        return posx;
    }
    /**
     * @post la valeur de posy n'est pas modifié
     * @return
     */
    public int getPosy() {
        return posy;
    }
    /**
     * permet de savoir si la case a ete touché ou non
     * @return la valeur stocké dans touche
     */
    public boolean getTouche() {
        return this.torpille;
    }

    /**
     * Renvoie l'id du vaisseau
     * @return id du vaisseu
     */
    public int getIdVaisseau(){
        return this.idVaisseau;
    }

}