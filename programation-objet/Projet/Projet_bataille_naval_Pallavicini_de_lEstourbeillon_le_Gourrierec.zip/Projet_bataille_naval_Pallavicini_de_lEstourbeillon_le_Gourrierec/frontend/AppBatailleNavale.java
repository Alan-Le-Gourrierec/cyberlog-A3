package frontend;

import java.awt.EventQueue;

/**
 * Application contenant la classe main
 * permet de lancer le jeu en appelant les méthodes permettant l'affichage de l'interface graphique
 * @author Alan Le Gourrierec, Joseph De L'Estourbeillon, Ewan Pallavicini
 */

public class AppBatailleNavale {
	public static void main(String[] args) throws Exception {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				// Construction de la fenetre
				Game fenetreAffichage = new Game();
				fenetreAffichage.setVisible(true);
			}
		});
	}
}
