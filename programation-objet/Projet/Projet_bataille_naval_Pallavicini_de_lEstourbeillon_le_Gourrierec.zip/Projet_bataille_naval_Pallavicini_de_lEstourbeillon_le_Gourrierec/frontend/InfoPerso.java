package frontend;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.Random;

/**
 * Un objet InfoPerso contenant :
 * la zone de texte pour entrer le nom du joueur
 * la zone de texte pour entrer le prénom du joueur
 * la zone de texte pour entrer l'âge du joueur
 * la liste des noms aléatoires
 * la liste des prénoms aléatoires
 * @author Alan Le Gourrierec, Joseph De L'Estourbeillon, Ewan Pallavicini
 */

class InfoPerso extends JDialog {
    private JTextField nomField; //zone de texte pour entrer le nom du joueur
    private JTextField prenomField; //zone de texte pour entrer le prénom du joueur
    private JTextField ageField; //zone de texte pour entrer l'âge du joueur
    private final String[] nom    = {"Lagaffe","Dubois","Durand","Durant"}; //génération de nom aléatoir pour faciliter les tests
    private final String[] prenom = {"Gerard","Gaston","Giselle","Frederico","Jean-Luc","Wilfried","Annette"}; //génération de prénom aléatoire pour faciliter les tests 
    
    /**
     * pour la création de info perso, nous allons utiliser des setter dans le but de prévenir
     * les potentiels erreur avec une programation défensive 
     */
    public InfoPerso() {
        
        setTitle("Informations Personnelles");
        setLayout(new GridLayout(4, 2));

        add(new JLabel("Prénom:"));
        prenomField = new JTextField();
        add(prenomField);

        add(new JLabel("Nom:"));
        nomField = new JTextField();
        add(nomField);

        add(new JLabel("Âge:"));
        ageField = new JTextField();
        add(ageField);

        // Bouton de remplissage automatique (aléatoire) + validation automatique
        JButton automatiqueButton = new JButton("Auto");
        automatiqueButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                prenomField.setText(getRandomElement(prenom));
                nomField.setText(getRandomElement(nom));
                ageField.setText("18");
                dispose(); // Ferme la boîte de dialogue si les entrées sont valides
            }
        });
        automatiqueButton.setForeground(Color.blue);
        add(automatiqueButton);

        // Bouton pour valider le remplissage
        JButton validerButton = new JButton("Valider");
        validerButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                if (isInputValid()) {
                    dispose(); // Ferme la boîte de dialogue si les entrées sont valides
                } else {
                    JOptionPane.showMessageDialog(InfoPerso.this, "Veuillez remplir tous les champs et entrer un âge valide.", "Erreur", JOptionPane.ERROR_MESSAGE);
                }
            }
        });
        validerButton.setForeground(Color.green);
        add(validerButton);


        setSize(300, 150);
        setLocationRelativeTo(Game.contentPanel);
        setModal(true); // Bloque l'accès aux autres fenêtres jusqu'à ce que cette boîte de dialogue soit fermée
    }

    /**
     * Vérifie si toutes les informations sont valides
     * @return true si toutes les informations sont valides sinon false et demande au joueur
     * de modifier les champs érroné 
     */
    public boolean isInputValid() {
        return !nomField.getText().isEmpty() 
            && !prenomField.getText().isEmpty() 
            && isAgeValid(ageField.getText());
    }

    // getters
    /**
     * Renvoie le nom du joueur
     * @return le nom du joueur sans le modifier
     */
    public String getNom() {
        return nomField.getText();
    }

    /**
     * Renvoie le prénom du joueur
     * @return le prénom du joueur sans le modifier
     */
    public String getPrenom() {
        return prenomField.getText();
    }

    /**
     * Renvoie l'âge du joueur
     * @return l'age du joueur sans le modifier
     */
    public int getAge() {
        try {
            return Integer.parseInt(ageField.getText());
        } catch (NumberFormatException e) {
            return -1; // Retourne -1 si l'âge n'est pas un nombre valide
        }
    }

    // méthodes
    /**
     * Vérifie si l'âge est valide
     * @param ageStr age de l'utilisateur en vérifiant que ce dernier sois bien valide  
     *               il doit être supérieur à 0 et un entier.
     * @return true si l'âge est valide, sinon false
     * le but du try/catch est de prévenir que l'utilisateur entre bien un entier.
     */
    private boolean isAgeValid(String ageStr) {
        try {
            int age = Integer.parseInt(ageStr);
            return age > 0; // L'âge doit être un entier positif
        } catch (NumberFormatException e) {
            return false; // Retourne faux si l'âge n'est pas un nombre valide
        }
    }

    /**
     * génération d'une fiche de personnage aléatoire
     * @param list entrer une liste de type string contenant des nom ou des prénom pour en obtenir un aléatoire
     * @return élément aléatoire de la liste
     */
    public String getRandomElement(String[] list) {
        Random random = new Random();
        int randomIndex = random.nextInt(list.length);
        return list[randomIndex];
    }
}