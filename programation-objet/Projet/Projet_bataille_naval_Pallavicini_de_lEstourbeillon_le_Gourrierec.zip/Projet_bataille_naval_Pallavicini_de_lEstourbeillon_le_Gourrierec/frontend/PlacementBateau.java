package frontend;

import backend.*;

import javax.swing.*;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 * Un objet PlacementBateau permettant de placer les bateaux et contenant :
 * les coordonnées x du bateau placé
 * les coordonnées y du bateau placé
 * un bouton de placement horizontal
 * un bouton de placement vertical
 * un bouton de placement vers le haut/la droite (selon horizontal ou vertical)
 * un bouton de placement vers le bas/la gauche (selon horizontal ou vertical)
 * un bouton valider
 * 
 * la liste des bateaux
 * le premier bateau à placer
 * l'identifiant du bateau actuel
 * le joueur
 * la grille liée à ce joueur
 * @author Alan Le Gourrierec, Joseph De L'Estourbeillon, Ewan Pallavicini
 */

public class PlacementBateau extends JPanel {
    private JTextField coordXField;
    private JTextField coordYField;
    private JRadioButton horizontalRadioButton;
    private JRadioButton verticalRadioButton;
    private JRadioButton trueRadioButton;
    private JRadioButton falseRadioButton;
    private JButton validerButton;

    private final TypeVaisseau [] vaisseaux = creationListeVaisseau();
    private TypeVaisseau vaisseauActuel = vaisseaux[0];
    private int idVaisseauActuel = 0;
    private Joueur joueur;
    private Grille plateauJoueur;

    /**
     * le but de ce constructeur est de créer les divers paramètres relatifs à la partie
     * et principalement les bateaux. Nous initialisons donc les bateau, leur position, leur type.
     * 
     * Deplus, nous ajoutons un afichage graphique pour simplifier l'utilisation et le placement 
     * des bateau
     * 
     * @param joueur entré d'un joueur qui est géré dans une autre classe avec comme information:
     *               son nom, son prénom et son age.
     */

    public PlacementBateau(Joueur joueur) {
        this.joueur = joueur;
        this.plateauJoueur = this.joueur.getGrille();
        this.plateauJoueur.affichagePlateau(320, 100,false);        
        Game.contentPanel.repaint();

        setLayout(new BorderLayout());
        setLayout(new GridLayout(0, 2)); // 0 rows, 2 columns

        coordXField = new JTextField(10);
        coordYField = new JTextField(10);

        JPanel orientationPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        JPanel activePanel = new JPanel(new FlowLayout(FlowLayout.LEFT));

        ButtonGroup orientationGroup = new ButtonGroup();
        horizontalRadioButton = new JRadioButton("Horizontal");
        verticalRadioButton = new JRadioButton("Vertical");
        orientationGroup.add(horizontalRadioButton);
        orientationGroup.add(verticalRadioButton);

        orientationPanel.add(horizontalRadioButton);
        orientationPanel.add(verticalRadioButton);

        ButtonGroup activeGroup = new ButtonGroup();
        trueRadioButton = new JRadioButton("Haut/droite");
        falseRadioButton = new JRadioButton("Bas/gauche");
        activeGroup.add(trueRadioButton);
        activeGroup.add(falseRadioButton);

        activePanel.add(trueRadioButton);
        activePanel.add(falseRadioButton);

        validerButton = new JButton("Valider");
        validerButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                // Validation des données
                if (validateData()) {
                    // Récupération des données
                    int x = Integer.parseInt(coordXField.getText())-1;
                    int y = Integer.parseInt(coordYField.getText())-1;
                    boolean axe = horizontalRadioButton.isSelected();
                    // Boolean.parseBoolean(textField3.getText());
                    boolean orientation = trueRadioButton.isSelected();
                    // Boolean.parse private boolean validateData() {
                    
                    Bateau vaisseau = new Bateau(x,y,orientation,axe,vaisseauActuel);
                    if (plateauJoueur.isValidPlace(vaisseau)){
                        System.out.println("[x] Données de placement récupérées :");
                        System.out.println("   x : " + x);
                        System.out.println("   y : " + y);
                        System.out.println("   axe : " + axe);
                        System.out.println("   orientation : " + orientation);
                        
                        swap();
                        
                        plateauJoueur.ajoutVaisseau(vaisseau);
                        plateauJoueur.affichagePlateau(320, 100,false);
                    }
                }
                if (vaisseauActuel==null){
                    remove(validerButton);
                    cacher();
                }
            }
        });
        add(validerButton, BorderLayout.SOUTH); // Ajout en bas


        add(new JLabel("Coordonnée X:"));
        add(coordXField);
        add(new JLabel("Coordonnée Y:"));
        add(coordYField);
        add(new JLabel("Axe:"));
        add(orientationPanel);
        add(new JLabel("Orientation:"));
        add(activePanel);
        add(validerButton, BorderLayout.SOUTH);
     

        repaint();
    }
    /**
     * 
     * @return renvoie true si les informations entré relatives au placement du bateau en question
     *         sont toutes correcte sinon false 
     */

    private boolean validateData() {
        try {
            Integer.parseInt(coordXField.getText());
            Integer.parseInt(coordYField.getText());
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(Game.contentPanel, "Les deux premiers champs doivent être des nombres entiers (1-10).", "Erreur", JOptionPane.WARNING_MESSAGE);
            return false;
        }

        // Vérifie qu'un choix a été fait dans chaque CheckBoxGroup
        if (!horizontalRadioButton.isSelected() && !verticalRadioButton.isSelected()) {
            JOptionPane.showMessageDialog(Game.contentPanel, "Le troisième champ doit être 'true' ou 'false'.", "Erreur", JOptionPane.WARNING_MESSAGE);
            return false;
        }
        if (!trueRadioButton.isSelected() && !falseRadioButton.isSelected()) {
            JOptionPane.showMessageDialog(Game.contentPanel, "Le quatrième champ doit être 'true' ou 'false'.", "Erreur", JOptionPane.WARNING_MESSAGE);
            return false;
        }

        return true;
    }

    private void swap(){
        if (vaisseauActuel == vaisseaux[vaisseaux.length-1]) vaisseauActuel = null;
        // Sinon on passe au suivant
        else vaisseauActuel = vaisseaux[++idVaisseauActuel];
    }
    /**
     * 
     * @return renvoie la liste contenant tout les bateaux du joueur avec les dimentions de ces derniers 
     */

    private TypeVaisseau [] creationListeVaisseau(){
        int i=0;
        TypeVaisseau [] liste = new TypeVaisseau[5];
        for(TypeVaisseau elem: TypeVaisseau.values()){
            liste[i]=elem;
            if (elem==TypeVaisseau.contreTorpilleur){
                liste[i+1]=elem;
                i++;
            }
            i++;
        }
        
        return liste;
    }

    /**
     * permet de cacher le plateau du joueur et aussi de voir si le jeu est terminé
     */
    private void cacher(){
        JButton cacher = new JButton("Terminer le Placement");
        cacher.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                System.out.println("Plateau caché pour joueur suivant");
                JOptionPane.showMessageDialog(Game.contentPanel,"Au tour du joueur suivant");
                Game.infoJoueur.setJoueur(joueur.getAdversaire());

                plateauJoueur.setVisiblePlateau(false);
                Container parent = getParent();
                
                parent.remove(PlacementBateau.this);
                parent.revalidate();
                parent.repaint();
                
                Game.placer.setVisible(true);
                
                if (Game.etat==true){
                    System.out.println("Lancement de la partie");
                    Game.infoJoueur.setText("Fin du placement !");
                    Game.infoJoueur.setJoueur(null);
                    Game.attaquer.setVisible(true);
                }
            }
        });
        cacher.setBounds(350, 500, 150, 30);
        cacher.setForeground(Color.red);
        add(cacher, BorderLayout.SOUTH);
    }
}


// Validation des deux premiers champs comme nombres
        // try {
        //     Integer.parseInt(textField1.getText());
        //     Integer.parseInt(textField2.getText());
        // } catch (NumberFormatException e) {
        //     JOptionPane.showMessageDialog(Game.contentPanel, "Les deux premiers champs doivent être des nombres entiers (1-10).", "Erreur", JOptionPane.WARNING_MESSAGE);
        //     return false;
        // }

        // // Validation des deux derniers champs comme booléens
        // String text3 = textField3.getText().toLowerCase();
        // String text4 = textField4.getText().toLowerCase();
        // if (!text3.equals("true") && !text3.equals("false")) {
        //     return false;
        // }
        // if (!text4.equals("true") && !text4.equals("false")) {
        //     return false;
        // }
        // Vérifie que les deux champs de texte contiennent des entiers

// private JTextField textField1;
    // private JTextField textField2;
    // private JTextField textField3;
    // private JTextField textField4;
    // private JButton validateButton;
    // private JPanel inputPanel;
    // private final TypeVaisseau [] vaisseaux = creationListeVaisseau();

    // private TypeVaisseau vaisseauActuel = vaisseaux[0];
    // private int idVaisseauActuel = 0;
    // private Joueur joueur;
    // private Grille plateauJoueur;

    // public PlacementBateau(Joueur joueur) {
    //     this.joueur = joueur;
    //     this.plateauJoueur = this.joueur.getGrille();
    //     this.plateauJoueur.affichagePlateau(320, 100,false);        
    //     Game.contentPanel.repaint();

    //     setLayout(new BorderLayout()); // Utilisation de BorderLayout
        
    //     this.inputPanel = new JPanel(new GridLayout(4, 2)); // JPanel pour les champs de texte
    //     add(this.inputPanel, BorderLayout.CENTER); // Ajout au centre
    //     setBorder(new EmptyBorder(5, 5, 5, 5));
    //     this.inputPanel.setVisible(true);

    //     // Ajout des zones de texte
    //     this.inputPanel.add(new JLabel("x :"));
    //     textField1 = new JTextField();
    //     this.inputPanel.add(textField1);
        
    //     this.inputPanel.add(new JLabel("y :"));
    //     textField2 = new JTextField();
    //     this.inputPanel.add(textField2);
        
    //     this.inputPanel.add(new JLabel("Axe :"));
    //     textField3 = new JTextField();
    //     this.inputPanel.add(textField3);
        
    //     this.inputPanel.add(new JLabel("Orientation :"));
    //     textField4 = new JTextField();
    //     this.inputPanel.add(textField4);
        
    //     // Bouton de validation
       