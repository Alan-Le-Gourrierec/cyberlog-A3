package frontend;

import backend.Joueur;

import java.awt.Color;
import java.awt.Font;
import java.awt.GridLayout;

import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingConstants;

/**
 * Un objet TexteAffichage permettant d'afficher une pop up contenant :
 * le texte du titre
 * le texte du contenu
 * @author Alan Le Gourrierec, Joseph De L'Estourbeillon, Ewan Pallavicini
 */

public class TexteAffichage extends JPanel{
    // attributs //
    private JLabel txt1;
    private JLabel txt2;

    // constructeur //
    public TexteAffichage() {
        setLayout(new GridLayout(2, 1)); // 2 lignes, 1 colonnes
        this.txt1 = new JLabel("");
        
        Font font = this.txt1.getFont();
        Font newFont = font.deriveFont(font.getSize() + 4.0f); // Agrandir la taille de police de 4 points
        this.txt1.setFont(newFont);

        txt1.setForeground(Color.blue);
        txt1.setHorizontalAlignment(SwingConstants.CENTER);
        add(this.txt1);
        
        this.txt2 = new JLabel("");
        txt2.setHorizontalAlignment(SwingConstants.CENTER);
        add(this.txt2);
    }

    /**
     * défini le texte à afficher en titre
     * @param txt1 texte à afficher
     */
    public void setText(String txt1){
        this.txt1.setText(txt1);
    }

    /**
     * Défini le joueur à afficher en contenu
     * @param joueur joueur pour lequel c'est le tour
     * @pre le joueur ne doit pas être null
     * @pre le tour doit être celui du joueur
     */
    public void setJoueur(Joueur joueur){
        if (joueur==null){
            this.txt2.setText("");
        }
        else{
            this.txt2.setText("C'est au tour du JOUEUR "+joueur.getID()+" ("+joueur.getPrenom()+" "+joueur.getNom()+")");
        }
    }

    /**
     * Renvoie le titre du texte
     * @return titre actuel
     */
    public String getText(){
        return txt1.getText();
    }

    /**
     * Renvoie le contenu du texte
     * @return contenu actuel
     */
    public String getJoueur(){
        return txt2.getText();
    }
}
