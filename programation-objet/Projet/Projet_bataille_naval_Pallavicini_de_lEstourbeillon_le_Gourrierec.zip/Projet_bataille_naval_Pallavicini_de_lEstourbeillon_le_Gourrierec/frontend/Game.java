package frontend;

import backend.*;

import javax.swing.*;
import javax.swing.border.EmptyBorder;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

/**
 * Un objet Game permettant de jouer au jeu contenant :
 * le premier joueur
 * le second joueur
 * le joueur pour lequel c'est le tour de tirer
 * l'état actuel du placement des bateaux
 * les informations du joueur
 * le bouton placer (pour les bateaux)
 * le bouton attaquer (pour les bateaux)
 * la fenêtre d'affichage
 * la barre de menu contenant :
 *      -le menu du jeu qui contient :
 *          -les informations sur le jeu (non implémenté car les règles du jeu se situent dans README.md)
 *          -quitter le jeu
 *      -le menu de la partie qui contient :
 *          - placement aléatoire des bateaux (pas implémenté, mais en prévision d'une potentielle reprise du projet)
 *          - la création d'une nouvelle partie
 *          - terminer qui correspond à la fermeture du menu déroulant
 *      -le menu d'aide (pas implémenté étant donné que les règles du jeu se situent dans README.md)
 * 
 * @author Alan Le Gourrierec, Joseph De L'Estourbeillon, Ewan Pallavicini
 */

public class Game extends JFrame{
    // Attributs //
    private Joueur joueur1; // premier joueur
    private Joueur joueur2; // second joueur
    private Joueur joueurActuel = joueur1; // joueur actuel
    
    public static boolean etat = true;
    public static TexteAffichage infoJoueur = new TexteAffichage();
    public static JButton placer;
    public static JButton attaquer;
    public static JPanel contentPanel;

    // Barre de menu de la fenetre :
	private JMenuBar menuBar = new JMenuBar();
	
    // Elements de la barre de menu : 
	private JMenu menuJeu     = new JMenu("Bataille Navale");
	private JMenu menuPartie  = new JMenu("Partie");
	private JMenu menuAide    = new JMenu("Aide");
	
	// Sous-menus de menuJeu
	private JMenuItem itemInfo    = new JMenuItem("Informations");
	private JMenuItem itemQuitter = new JMenuItem("Quitter");
    // Sous-menus de menuPartie : 
    private JMenuItem itemCreerAleatoire = new JMenuItem("Placement aléatoire Aleatoire");
	private JMenuItem itemNouveau        = new JMenuItem("Nouvelle");
	private JMenuItem itemArret          = new JMenuItem("Terminer");


    // constructeur //
    public Game() {
        // Création de la fenetre d'affichage :
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 900, 700);
        contentPanel = new JPanel();
        contentPanel.setBackground(new Color(120, 120, 120)); // vert clair pâle => Color(100, 150, 120)
        contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
        contentPanel.setLayout(null);
        setContentPane(contentPanel);

        addMenuBar();
        
        // Affichage des infos joueurs
        infoJoueur.setBounds(300, 20, 300, 50);
        infoJoueur.setText("BIENVENUE à la Bataille Navale !");
        contentPanel.add(infoJoueur);
    }

    // Methodes classe
    private Joueur initJoueur(int id){ // nom par defaut : "Joueur [ID]"
        InfoPerso dialog = new InfoPerso();
        dialog.setDefaultCloseOperation(JDialog.DO_NOTHING_ON_CLOSE); // Empêche la fermeture de la boîte de dialogue

        dialog.addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent e) {
                if (dialog.isInputValid()) {
                    dialog.dispose(); // Ferme la boîte de dialogue si les entrées sont valides
                } else {
                    JOptionPane.showMessageDialog(dialog, "Veuillez remplir tous les champs et entrer un âge valide.", "Erreur", JOptionPane.ERROR_MESSAGE);
                }
            }
        });
        dialog.setVisible(true);

        String nom = dialog.getNom();
        String prenom = dialog.getPrenom();
        int age = dialog.getAge();
        String msg = "Bienvenue "+prenom+" "+nom;
        String titre = "JOUEUR "+id+" !";
        JOptionPane.showMessageDialog(contentPanel, msg, titre, JOptionPane.INFORMATION_MESSAGE);
        return new Joueur(id,nom,prenom,age);
    }

    // lancement d'une partie
    private void partie(){
        // placement des bateau : 
        commencerAPlacer();
        commencerAJouer();
    }


    //**********Gestion des menus**********
	// Initialisation des menus
    private void addMenuBar(){
		this.menuPartie.add(itemCreerAleatoire);
		this.menuPartie.add(itemNouveau);
		this.menuPartie.addSeparator();
		this.menuPartie.add(itemArret);
		
		this.menuJeu.add(itemInfo);
		this.menuJeu.add(itemQuitter);

		// Ajout de raccourcis clavier
		this.itemCreerAleatoire.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_R, KeyEvent.CTRL_DOWN_MASK));
		this.itemNouveau.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_N, KeyEvent.CTRL_DOWN_MASK));
		this.itemQuitter.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_Q, KeyEvent.CTRL_DOWN_MASK));
		
		// Listener Menu
		this.itemQuitter.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e) {
				System.exit(0);
			}
		});
		this.itemNouveau.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e) {
                JOptionPane.showMessageDialog(contentPanel, "Nouvelle partie !", "Cool !", JOptionPane.INFORMATION_MESSAGE);
                joueur1 = initJoueur(1);
                joueur2 = initJoueur(2);
                joueur1.setAdversaire(joueur2);
                joueur2.setAdversaire(joueur1);
                
                joueurActuel = joueur1;
                
                partie();
			}
		});
        this.itemArret.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e) {
                System.out.println("Le jeu a été arrêté");
                JOptionPane.showMessageDialog(contentPanel," Le joueur "+joueurActuel.getID()+" a GAGNÉ","Félicitation",JOptionPane.INFORMATION_MESSAGE);
                
                reinitialiserFenetre();

                infoJoueur.setText(joueurActuel.getPrenom()+" "+joueurActuel.getNom()+" a GAGNÉ");

                contentPanel.repaint();
			}
		});
        
        this.menuBar.add(menuJeu);
		this.menuBar.add(menuPartie);
		this.menuBar.add(menuAide);
		this.setJMenuBar(menuBar);
    }

    private void commencerAPlacer(){
        placer = new JButton("Placer les bateaux");
        placer.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                System.out.println(infoJoueur.getJoueur());
                infoJoueur.setText("Placement des bateaux");
                infoJoueur.setJoueur(joueurActuel);

                PlacementBateau questionnaire = new PlacementBateau(joueurActuel);
                questionnaire.setBounds(250, 400, 400, 150);
                contentPanel.add(questionnaire);

                placer.setVisible(false);
                
                joueurActuel=joueurActuel.getAdversaire();

                if (etat==false){
                    contentPanel.remove(placer);
                    contentPanel.validate();
                    contentPanel.repaint();
                }
                etat=!etat;
            }
        });
        placer.setBounds(350, 200, 200, 50);
        contentPanel.add(placer);
    }

    private void commencerAJouer(){
        attaquer = new JButton("Attaquer l'adversaire");
        attaquer.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                System.out.println(infoJoueur.getJoueur());
                infoJoueur.setText("Attaque");
                infoJoueur.setJoueur(joueurActuel);

                lancerAttaque();

                contentPanel.remove(attaquer);
                
                contentPanel.repaint();
            }
        });
        attaquer.setBounds(350, 200, 200, 50);
        attaquer.setVisible(false);
        contentPanel.add(attaquer);
    }

    private void lancerAttaque(){
        JButton afficher = new JButton("Attaque du joueur "+joueurActuel.getID());
        JButton suivant = new JButton("Fin de placement joueur "+joueurActuel.getID());
        
        afficher.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                System.out.println("Attaque du joueur "+joueurActuel.getID());
                joueurActuel.getGrille().affichagePlateau(100, 100,false);
                joueurActuel.getAdversaire().getGrille().affichagePlateau(100, 100,true);
                
                afficher.setVisible(false);
                suivant.setVisible(true);
                afficher.setText("Affichage joueur "+joueurActuel.getID());
                
                if (!joueurActuel.aGagner()){
                    joueurActuel.addUnTour();
                    joueurActuel.torpiller();
                }
                else {
                    System.out.println("Le joueur "+joueurActuel.getID()+" a GAGNÉ");
                    JOptionPane.showMessageDialog(contentPanel," Le joueur "+joueurActuel.getID()+" a GAGNÉ","Félicitation",JOptionPane.INFORMATION_MESSAGE);

                    reinitialiserFenetre();
                    infoJoueur.setText(joueurActuel.getPrenom()+" "+joueurActuel.getNom()+" a GAGNÉ");
                }
            }
        });
        afficher.setBounds(300, 530, 150, 30);
        afficher.setVisible(true);
        contentPanel.add(afficher);
        
        suivant.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                System.out.println("Joueur suivant");
                joueurActuel.getGrille().setVisiblePlateau(false);
                joueurActuel.getAdversaire().getGrille().setVisiblePlateau(false);
                suivant.setText("Fin de placement joueur "+joueurActuel.getID());
                
                afficher.setVisible(true);
                suivant.setVisible(false);
                infoJoueur.setJoueur(joueurActuel);
                
                joueurActuel = joueurActuel.getAdversaire();
            }
        });
        suivant.setBounds(500, 530, 200, 30);
        suivant.setVisible(false);
        contentPanel.add(suivant);
    }

    private void reinitialiserFenetre(){
        Component[] components = contentPanel.getComponents();
        for (Component component : components) {
            contentPanel.remove(component);
        }
        infoJoueur = new TexteAffichage();
        infoJoueur.setBounds(300, 20, 300, 50);
        infoJoueur.setText("BIENVENUE à la Bataille Navale !");
        contentPanel.add(infoJoueur);
        contentPanel.validate();
        contentPanel.repaint();
    }

}
