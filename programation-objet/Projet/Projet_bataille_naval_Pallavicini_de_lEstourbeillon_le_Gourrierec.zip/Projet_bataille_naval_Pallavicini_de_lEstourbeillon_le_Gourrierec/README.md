# Bataille-navale
Alan Le Gourrierec
Joseph De L'Estourbeillon
Ewan Pallavicini

Ceci est le projet de java basé sur la bataille navale. La répartition des tâches à été majoritairement faite de la façon suivante:
- backend : Ewan et Alan (nous nous sommes arrangés dans la création des classes)
- frontend : Joseph

Pour la partie graphique, nous avons utilisé java swing.
Pour la partie backend, nous avons choisie de principalement se concentrer sur une programmation défensive tout en y ajoutant de la javadoc.

---

### Gestion de projet

Pour la gestion de ce projet, nous avons choisi d'utiliser github pour diverse raisons :
- pour apprendre à mieux l'utiliser, ce qui sera utile pour les futurs projets
- pour avoir les dossiers partagés entre nous 

Vous pouvez le copier en utilisant :
```bash
git clone https://github.com/Alan-Le-Gourrierec/bataille-navale
```

---

# Fonctionnement du projet

Une fois le programme lancé dans AppBatailleNavale.java :
- cliquer sur le menu déroulant Partie 
- cliquer sur nouvelle partie ou faire ctrl + n

Une fois ceci effectué, vous arriverez sur un nouvel onglet demandant aux 2 joueurs d'entrer les informations suivantes :
- nom
- prenom
- age

Vous pouvez aussi les générer automatiquement en cliquant sur le bouton <font color = blue> auto </font>. Quand le premier joueur aura terminé, ceci passera au tour du second.

Nous passerons à ce moment là à une phase de placement. Vous devrez donc entrer les coordonnées (x et y) d'une des deux extrémitées et ensuite selectionnez l'orientation de notre bateau :
- axe : détermine si notre bateau est placé à la verticale ou à l'horizontal
- Orientation : détermine si le bateau est vers le haut (si verticale) ou vers la droite (si horizontal) ou sinon vers le bas (si vertical) ou vers la gauche (si horizontal).

> /!\ si le bateau est mal placé, vous aurez une notification précisant s'il est en dehors des limites du plateau et/ou si la case d'origine du bateau n'est pas valide.

Une fois ceci réalisé par les deux joueurs, nous pouvons commencer le jeu !! Pour ce faire, vous aller devoir cliquer sur une case du plateau de droite (représentant le plateau adverse). 

La case sélectionnée passera en rouge si il y avait un bateau et en bleu si elle n'en contenait pas. Vous pouvez aussi voir si l'adversaire a touché vos bateaux sur le plateau de gauche affichant votre jeu avec le placement de vos bateau et les diverses attaques de votre adversaire (bleu si ce n'est pas une case avec un bateau et rouge si elle contient un de vos bateaux).

Une fois un bateau coulé, vous serez informé par une boite de dialogue vous le spécifiant et quand tout les bateaux de votre adversaire sont coulés, vous avez gagné !!!
