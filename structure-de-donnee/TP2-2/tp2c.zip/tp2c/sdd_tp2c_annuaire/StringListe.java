package sdd_tp2c_annuaire;

public class StringListe {
	String contenu1;
	String contenu2;
	StringListe suivant;

	public StringListe(String val1, String val2, StringListe li) {
		contenu1 = val1;
		contenu2 = val2;
		suivant  = li;
	}

}
